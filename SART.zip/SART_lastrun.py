#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v3.0.0b7),
    on February 11, 2020, at 10:34
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'SART'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath="P:\\Human_Systems\\HSI\\Hayden\\Carsten's mindfulness interventions\\SART\\SART_lastrun.py",
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1920, 1200], fullscr=True, screen=0,
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Initialize components for Routine "Start"
StartClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text="Welcome to the experiment. Today your task is to watch a series of single digits presented one after another and respond accordingly. You should make your response using the computer's keyboard. You are required to press the spacebar for every number except '3'. I.e. you need to press the spacebar to all of the following numbers presented :'1', '2'. '4', '5', '6', '7', '8', '9', and '0'. Press the space bar to continue.",
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Start2"
Start2Clock = core.Clock()
text_2 = visual.TextStim(win=win, name='text_2',
    text='You will also periodically be presented with a set of two questions as to how focused on the task you are, as well as how aware of your focus you were. Responses to each of these questions should be in relation to your state of mind immediately prior to the probe questions, and should range from 1 (on task/aware) to 6 (off task/unaware). A short practice series will follow where you will be provided with feedback. Press space to begin. ',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Trial"
TrialClock = core.Clock()
Trial_Text = visual.TextStim(win=win, name='Trial_Text',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
secondQuestion = visual.TextStim(win=win, name='secondQuestion',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
image = visual.ImageStim(
    win=win, name='image',
    image='sin', mask=None,
    ori=0, pos=(0, -0.5), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "ISI"
ISIClock = core.Clock()
ISI_Text = visual.TextStim(win=win, name='ISI_Text',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "feedback"
feedbackClock = core.Clock()
#msg variable just needs some value at start
msg=''
text_3 = visual.TextStim(win=win, name='text_3',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "Instructions"
InstructionsClock = core.Clock()
InstructionsText3 = visual.TextStim(win=win, name='InstructionsText3',
    text="Ok, that's the practice done. Are you ready for the real thing? The real thing won't include feedback and because of this, it will appear quicker to you initially. If you have any questions, now is the time to ask. If you're ready to proceed, press the spacebar to begin the real thing!",
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Trial"
TrialClock = core.Clock()
Trial_Text = visual.TextStim(win=win, name='Trial_Text',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
secondQuestion = visual.TextStim(win=win, name='secondQuestion',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
image = visual.ImageStim(
    win=win, name='image',
    image='sin', mask=None,
    ori=0, pos=(0, -0.5), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "ISI"
ISIClock = core.Clock()
ISI_Text = visual.TextStim(win=win, name='ISI_Text',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Trial"
TrialClock = core.Clock()
Trial_Text = visual.TextStim(win=win, name='Trial_Text',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
secondQuestion = visual.TextStim(win=win, name='secondQuestion',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
image = visual.ImageStim(
    win=win, name='image',
    image='sin', mask=None,
    ori=0, pos=(0, -0.5), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "ISI"
ISIClock = core.Clock()
ISI_Text = visual.TextStim(win=win, name='ISI_Text',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='Black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Start"-------
t = 0
StartClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp_2 = event.BuilderKeyResponse()
# keep track of which components have finished
StartComponents = [text, key_resp_2]
for thisComponent in StartComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Start"-------
while continueRoutine:
    # get current time
    t = StartClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if t >= 0.0 and text.status == NOT_STARTED:
        # keep track of start time/frame for later
        text.tStart = t
        text.frameNStart = frameN  # exact frame index
        text.setAutoDraw(True)
    
    # *key_resp_2* updates
    if t >= 0.0 and key_resp_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_2.tStart = t
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if key_resp_2.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_2.keys = theseKeys[-1]  # just the last key pressed
            key_resp_2.rt = key_resp_2.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in StartComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Start"-------
for thisComponent in StartComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_2.keys in ['', [], None]:  # No response was made
    key_resp_2.keys=None
thisExp.addData('key_resp_2.keys',key_resp_2.keys)
if key_resp_2.keys != None:  # we had a response
    thisExp.addData('key_resp_2.rt', key_resp_2.rt)
thisExp.nextEntry()
# the Routine "Start" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Start2"-------
t = 0
Start2Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp_3 = event.BuilderKeyResponse()
# keep track of which components have finished
Start2Components = [text_2, key_resp_3]
for thisComponent in Start2Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Start2"-------
while continueRoutine:
    # get current time
    t = Start2Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_2* updates
    if t >= 0.0 and text_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        text_2.tStart = t
        text_2.frameNStart = frameN  # exact frame index
        text_2.setAutoDraw(True)
    
    # *key_resp_3* updates
    if t >= 0.0 and key_resp_3.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_3.tStart = t
        key_resp_3.frameNStart = frameN  # exact frame index
        key_resp_3.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if key_resp_3.status == STARTED:
        theseKeys = event.getKeys()
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_3.keys = theseKeys[-1]  # just the last key pressed
            key_resp_3.rt = key_resp_3.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Start2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Start2"-------
for thisComponent in Start2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_3.keys in ['', [], None]:  # No response was made
    key_resp_3.keys=None
thisExp.addData('key_resp_3.keys',key_resp_3.keys)
if key_resp_3.keys != None:  # we had a response
    thisExp.addData('key_resp_3.rt', key_resp_3.rt)
thisExp.nextEntry()
# the Routine "Start2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Practice = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Practice.xlsx'),
    seed=None, name='Practice')
thisExp.addLoop(Practice)  # add the loop to the experiment
thisPractice = Practice.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisPractice.rgb)
if thisPractice != None:
    for paramName in thisPractice:
        exec('{} = thisPractice[paramName]'.format(paramName))

for thisPractice in Practice:
    currentLoop = Practice
    # abbreviate parameter names if possible (e.g. rgb = thisPractice.rgb)
    if thisPractice != None:
        for paramName in thisPractice:
            exec('{} = thisPractice[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Trial"-------
    t = 0
    TrialClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    Trial_Text.setText(text)
    Trial_Response = event.BuilderKeyResponse()
    secondQuestion.setText(text2)
    secondQuestionResponse = event.BuilderKeyResponse()
    image.setImage(imageFile)
    # keep track of which components have finished
    TrialComponents = [Trial_Text, Trial_Response, secondQuestion, secondQuestionResponse, image]
    for thisComponent in TrialComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "Trial"-------
    while continueRoutine:
        # get current time
        t = TrialClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Trial_Text* updates
        if t >= 0.0 and Trial_Text.status == NOT_STARTED:
            # keep track of start time/frame for later
            Trial_Text.tStart = t
            Trial_Text.frameNStart = frameN  # exact frame index
            Trial_Text.setAutoDraw(True)
        frameRemains = 0.0 + Text_duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if Trial_Text.status == STARTED and t >= frameRemains:
            Trial_Text.setAutoDraw(False)
        
        # *Trial_Response* updates
        if t >= 0.0 and Trial_Response.status == NOT_STARTED:
            # keep track of start time/frame for later
            Trial_Response.tStart = t
            Trial_Response.frameNStart = frameN  # exact frame index
            Trial_Response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(Trial_Response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = 0.0 + Text_duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if Trial_Response.status == STARTED and t >= frameRemains:
            Trial_Response.status = STOPPED
        if Trial_Response.status == STARTED:
            theseKeys = event.getKeys(keyList=['1', '2', '3', '4', '5', '6', 'space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                Trial_Response.keys = theseKeys[-1]  # just the last key pressed
                Trial_Response.rt = Trial_Response.clock.getTime()
                # was this 'correct'?
                if (Trial_Response.keys == str(corrAns)) or (Trial_Response.keys == corrAns):
                    Trial_Response.corr = 1
                else:
                    Trial_Response.corr = 0
        
        # *secondQuestion* updates
        if t >= text2start and secondQuestion.status == NOT_STARTED:
            # keep track of start time/frame for later
            secondQuestion.tStart = t
            secondQuestion.frameNStart = frameN  # exact frame index
            secondQuestion.setAutoDraw(True)
        frameRemains = text2start + text2duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if secondQuestion.status == STARTED and t >= frameRemains:
            secondQuestion.setAutoDraw(False)
        
        # *secondQuestionResponse* updates
        if t >= text2start and secondQuestionResponse.status == NOT_STARTED:
            # keep track of start time/frame for later
            secondQuestionResponse.tStart = t
            secondQuestionResponse.frameNStart = frameN  # exact frame index
            secondQuestionResponse.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(secondQuestionResponse.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = text2start + text2duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if secondQuestionResponse.status == STARTED and t >= frameRemains:
            secondQuestionResponse.status = STOPPED
        if secondQuestionResponse.status == STARTED:
            theseKeys = event.getKeys(keyList=['1', '2', '3', '4', '5', '6', 'space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                secondQuestionResponse.keys = theseKeys[-1]  # just the last key pressed
                secondQuestionResponse.rt = secondQuestionResponse.clock.getTime()
                # was this 'correct'?
                if (secondQuestionResponse.keys == str(corrAns)) or (secondQuestionResponse.keys == corrAns):
                    secondQuestionResponse.corr = 1
                else:
                    secondQuestionResponse.corr = 0
        
        # *image* updates
        if t >= 0.0 and image.status == NOT_STARTED:
            # keep track of start time/frame for later
            image.tStart = t
            image.frameNStart = frameN  # exact frame index
            image.setAutoDraw(True)
        frameRemains = 0.0 + imageDur- win.monitorFramePeriod * 0.75  # most of one frame period left
        if image.status == STARTED and t >= frameRemains:
            image.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in TrialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Trial"-------
    for thisComponent in TrialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if Trial_Response.keys in ['', [], None]:  # No response was made
        Trial_Response.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           Trial_Response.corr = 1;  # correct non-response
        else:
           Trial_Response.corr = 0;  # failed to respond (incorrectly)
    # store data for Practice (TrialHandler)
    Practice.addData('Trial_Response.keys',Trial_Response.keys)
    Practice.addData('Trial_Response.corr', Trial_Response.corr)
    if Trial_Response.keys != None:  # we had a response
        Practice.addData('Trial_Response.rt', Trial_Response.rt)
    # check responses
    if secondQuestionResponse.keys in ['', [], None]:  # No response was made
        secondQuestionResponse.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           secondQuestionResponse.corr = 1;  # correct non-response
        else:
           secondQuestionResponse.corr = 0;  # failed to respond (incorrectly)
    # store data for Practice (TrialHandler)
    Practice.addData('secondQuestionResponse.keys',secondQuestionResponse.keys)
    Practice.addData('secondQuestionResponse.corr', secondQuestionResponse.corr)
    if secondQuestionResponse.keys != None:  # we had a response
        Practice.addData('secondQuestionResponse.rt', secondQuestionResponse.rt)
    # the Routine "Trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ISI"-------
    t = 0
    ISIClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(0.900000)
    # update component parameters for each repeat
    ISI_Response = event.BuilderKeyResponse()
    # keep track of which components have finished
    ISIComponents = [ISI_Text, ISI_Response]
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "ISI"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = ISIClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ISI_Text* updates
        if t >= 0.0 and ISI_Text.status == NOT_STARTED:
            # keep track of start time/frame for later
            ISI_Text.tStart = t
            ISI_Text.frameNStart = frameN  # exact frame index
            ISI_Text.setAutoDraw(True)
        frameRemains = 0.0 + .9- win.monitorFramePeriod * 0.75  # most of one frame period left
        if ISI_Text.status == STARTED and t >= frameRemains:
            ISI_Text.setAutoDraw(False)
        
        # *ISI_Response* updates
        if t >= 0.0 and ISI_Response.status == NOT_STARTED:
            # keep track of start time/frame for later
            ISI_Response.tStart = t
            ISI_Response.frameNStart = frameN  # exact frame index
            ISI_Response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(ISI_Response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = 0.0 + 0.9- win.monitorFramePeriod * 0.75  # most of one frame period left
        if ISI_Response.status == STARTED and t >= frameRemains:
            ISI_Response.status = STOPPED
        if ISI_Response.status == STARTED:
            theseKeys = event.getKeys(keyList=['1', '2', '3', '4', '5', '6', 'space', 'none'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                ISI_Response.keys = theseKeys[-1]  # just the last key pressed
                ISI_Response.rt = ISI_Response.clock.getTime()
                # was this 'correct'?
                if (ISI_Response.keys == str(corrAns)) or (ISI_Response.keys == corrAns):
                    ISI_Response.corr = 1
                else:
                    ISI_Response.corr = 0
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ISIComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ISI"-------
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if ISI_Response.keys in ['', [], None]:  # No response was made
        ISI_Response.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           ISI_Response.corr = 1;  # correct non-response
        else:
           ISI_Response.corr = 0;  # failed to respond (incorrectly)
    # store data for Practice (TrialHandler)
    Practice.addData('ISI_Response.keys',ISI_Response.keys)
    Practice.addData('ISI_Response.corr', ISI_Response.corr)
    if ISI_Response.keys != None:  # we had a response
        Practice.addData('ISI_Response.rt', ISI_Response.rt)
    
    # ------Prepare to start Routine "feedback"-------
    t = 0
    feedbackClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(0.250000)
    # update component parameters for each repeat
    if ISI_Response.corr:#stored on last run routine
      msg="Correct!"
    else:
      msg="Oops! That was wrong"
    text_3.setText(msg)
    # keep track of which components have finished
    feedbackComponents = [text_3]
    for thisComponent in feedbackComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "feedback"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = feedbackClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        # *text_3* updates
        if t >= 0.0 and text_3.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_3.tStart = t
            text_3.frameNStart = frameN  # exact frame index
            text_3.setAutoDraw(True)
        frameRemains = 0.0 + 0.25- win.monitorFramePeriod * 0.75  # most of one frame period left
        if text_3.status == STARTED and t >= frameRemains:
            text_3.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in feedbackComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "feedback"-------
    for thisComponent in feedbackComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    thisExp.nextEntry()
    
# completed 1 repeats of 'Practice'


# ------Prepare to start Routine "Instructions"-------
t = 0
InstructionsClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp_4 = event.BuilderKeyResponse()
# keep track of which components have finished
InstructionsComponents = [InstructionsText3, key_resp_4]
for thisComponent in InstructionsComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Instructions"-------
while continueRoutine:
    # get current time
    t = InstructionsClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *InstructionsText3* updates
    if t >= 0.0 and InstructionsText3.status == NOT_STARTED:
        # keep track of start time/frame for later
        InstructionsText3.tStart = t
        InstructionsText3.frameNStart = frameN  # exact frame index
        InstructionsText3.setAutoDraw(True)
    
    # *key_resp_4* updates
    if t >= 0.0 and key_resp_4.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_4.tStart = t
        key_resp_4.frameNStart = frameN  # exact frame index
        key_resp_4.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_4.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if key_resp_4.status == STARTED:
        theseKeys = event.getKeys(keyList=['y', 'n', 'left', 'right', 'space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_4.keys = theseKeys[-1]  # just the last key pressed
            key_resp_4.rt = key_resp_4.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in InstructionsComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instructions"-------
for thisComponent in InstructionsComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_4.keys in ['', [], None]:  # No response was made
    key_resp_4.keys=None
thisExp.addData('key_resp_4.keys',key_resp_4.keys)
if key_resp_4.keys != None:  # we had a response
    thisExp.addData('key_resp_4.rt', key_resp_4.rt)
thisExp.nextEntry()
# the Routine "Instructions" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Block1 = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Block.xlsx'),
    seed=None, name='Block1')
thisExp.addLoop(Block1)  # add the loop to the experiment
thisBlock1 = Block1.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock1.rgb)
if thisBlock1 != None:
    for paramName in thisBlock1:
        exec('{} = thisBlock1[paramName]'.format(paramName))

for thisBlock1 in Block1:
    currentLoop = Block1
    # abbreviate parameter names if possible (e.g. rgb = thisBlock1.rgb)
    if thisBlock1 != None:
        for paramName in thisBlock1:
            exec('{} = thisBlock1[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Trial"-------
    t = 0
    TrialClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    Trial_Text.setText(text)
    Trial_Response = event.BuilderKeyResponse()
    secondQuestion.setText(text2)
    secondQuestionResponse = event.BuilderKeyResponse()
    image.setImage(imageFile)
    # keep track of which components have finished
    TrialComponents = [Trial_Text, Trial_Response, secondQuestion, secondQuestionResponse, image]
    for thisComponent in TrialComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "Trial"-------
    while continueRoutine:
        # get current time
        t = TrialClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Trial_Text* updates
        if t >= 0.0 and Trial_Text.status == NOT_STARTED:
            # keep track of start time/frame for later
            Trial_Text.tStart = t
            Trial_Text.frameNStart = frameN  # exact frame index
            Trial_Text.setAutoDraw(True)
        frameRemains = 0.0 + Text_duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if Trial_Text.status == STARTED and t >= frameRemains:
            Trial_Text.setAutoDraw(False)
        
        # *Trial_Response* updates
        if t >= 0.0 and Trial_Response.status == NOT_STARTED:
            # keep track of start time/frame for later
            Trial_Response.tStart = t
            Trial_Response.frameNStart = frameN  # exact frame index
            Trial_Response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(Trial_Response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = 0.0 + Text_duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if Trial_Response.status == STARTED and t >= frameRemains:
            Trial_Response.status = STOPPED
        if Trial_Response.status == STARTED:
            theseKeys = event.getKeys(keyList=['1', '2', '3', '4', '5', '6', 'space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                Trial_Response.keys = theseKeys[-1]  # just the last key pressed
                Trial_Response.rt = Trial_Response.clock.getTime()
                # was this 'correct'?
                if (Trial_Response.keys == str(corrAns)) or (Trial_Response.keys == corrAns):
                    Trial_Response.corr = 1
                else:
                    Trial_Response.corr = 0
        
        # *secondQuestion* updates
        if t >= text2start and secondQuestion.status == NOT_STARTED:
            # keep track of start time/frame for later
            secondQuestion.tStart = t
            secondQuestion.frameNStart = frameN  # exact frame index
            secondQuestion.setAutoDraw(True)
        frameRemains = text2start + text2duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if secondQuestion.status == STARTED and t >= frameRemains:
            secondQuestion.setAutoDraw(False)
        
        # *secondQuestionResponse* updates
        if t >= text2start and secondQuestionResponse.status == NOT_STARTED:
            # keep track of start time/frame for later
            secondQuestionResponse.tStart = t
            secondQuestionResponse.frameNStart = frameN  # exact frame index
            secondQuestionResponse.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(secondQuestionResponse.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = text2start + text2duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if secondQuestionResponse.status == STARTED and t >= frameRemains:
            secondQuestionResponse.status = STOPPED
        if secondQuestionResponse.status == STARTED:
            theseKeys = event.getKeys(keyList=['1', '2', '3', '4', '5', '6', 'space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                secondQuestionResponse.keys = theseKeys[-1]  # just the last key pressed
                secondQuestionResponse.rt = secondQuestionResponse.clock.getTime()
                # was this 'correct'?
                if (secondQuestionResponse.keys == str(corrAns)) or (secondQuestionResponse.keys == corrAns):
                    secondQuestionResponse.corr = 1
                else:
                    secondQuestionResponse.corr = 0
        
        # *image* updates
        if t >= 0.0 and image.status == NOT_STARTED:
            # keep track of start time/frame for later
            image.tStart = t
            image.frameNStart = frameN  # exact frame index
            image.setAutoDraw(True)
        frameRemains = 0.0 + imageDur- win.monitorFramePeriod * 0.75  # most of one frame period left
        if image.status == STARTED and t >= frameRemains:
            image.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in TrialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Trial"-------
    for thisComponent in TrialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if Trial_Response.keys in ['', [], None]:  # No response was made
        Trial_Response.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           Trial_Response.corr = 1;  # correct non-response
        else:
           Trial_Response.corr = 0;  # failed to respond (incorrectly)
    # store data for Block1 (TrialHandler)
    Block1.addData('Trial_Response.keys',Trial_Response.keys)
    Block1.addData('Trial_Response.corr', Trial_Response.corr)
    if Trial_Response.keys != None:  # we had a response
        Block1.addData('Trial_Response.rt', Trial_Response.rt)
    # check responses
    if secondQuestionResponse.keys in ['', [], None]:  # No response was made
        secondQuestionResponse.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           secondQuestionResponse.corr = 1;  # correct non-response
        else:
           secondQuestionResponse.corr = 0;  # failed to respond (incorrectly)
    # store data for Block1 (TrialHandler)
    Block1.addData('secondQuestionResponse.keys',secondQuestionResponse.keys)
    Block1.addData('secondQuestionResponse.corr', secondQuestionResponse.corr)
    if secondQuestionResponse.keys != None:  # we had a response
        Block1.addData('secondQuestionResponse.rt', secondQuestionResponse.rt)
    # the Routine "Trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ISI"-------
    t = 0
    ISIClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(0.900000)
    # update component parameters for each repeat
    ISI_Response = event.BuilderKeyResponse()
    # keep track of which components have finished
    ISIComponents = [ISI_Text, ISI_Response]
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "ISI"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = ISIClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ISI_Text* updates
        if t >= 0.0 and ISI_Text.status == NOT_STARTED:
            # keep track of start time/frame for later
            ISI_Text.tStart = t
            ISI_Text.frameNStart = frameN  # exact frame index
            ISI_Text.setAutoDraw(True)
        frameRemains = 0.0 + .9- win.monitorFramePeriod * 0.75  # most of one frame period left
        if ISI_Text.status == STARTED and t >= frameRemains:
            ISI_Text.setAutoDraw(False)
        
        # *ISI_Response* updates
        if t >= 0.0 and ISI_Response.status == NOT_STARTED:
            # keep track of start time/frame for later
            ISI_Response.tStart = t
            ISI_Response.frameNStart = frameN  # exact frame index
            ISI_Response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(ISI_Response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = 0.0 + 0.9- win.monitorFramePeriod * 0.75  # most of one frame period left
        if ISI_Response.status == STARTED and t >= frameRemains:
            ISI_Response.status = STOPPED
        if ISI_Response.status == STARTED:
            theseKeys = event.getKeys(keyList=['1', '2', '3', '4', '5', '6', 'space', 'none'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                ISI_Response.keys = theseKeys[-1]  # just the last key pressed
                ISI_Response.rt = ISI_Response.clock.getTime()
                # was this 'correct'?
                if (ISI_Response.keys == str(corrAns)) or (ISI_Response.keys == corrAns):
                    ISI_Response.corr = 1
                else:
                    ISI_Response.corr = 0
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ISIComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ISI"-------
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if ISI_Response.keys in ['', [], None]:  # No response was made
        ISI_Response.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           ISI_Response.corr = 1;  # correct non-response
        else:
           ISI_Response.corr = 0;  # failed to respond (incorrectly)
    # store data for Block1 (TrialHandler)
    Block1.addData('ISI_Response.keys',ISI_Response.keys)
    Block1.addData('ISI_Response.corr', ISI_Response.corr)
    if ISI_Response.keys != None:  # we had a response
        Block1.addData('ISI_Response.rt', ISI_Response.rt)
    thisExp.nextEntry()
    
# completed 1 repeats of 'Block1'


# set up handler to look after randomisation of conditions etc
Block2 = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Block.xlsx'),
    seed=None, name='Block2')
thisExp.addLoop(Block2)  # add the loop to the experiment
thisBlock2 = Block2.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock2.rgb)
if thisBlock2 != None:
    for paramName in thisBlock2:
        exec('{} = thisBlock2[paramName]'.format(paramName))

for thisBlock2 in Block2:
    currentLoop = Block2
    # abbreviate parameter names if possible (e.g. rgb = thisBlock2.rgb)
    if thisBlock2 != None:
        for paramName in thisBlock2:
            exec('{} = thisBlock2[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Trial"-------
    t = 0
    TrialClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    Trial_Text.setText(text)
    Trial_Response = event.BuilderKeyResponse()
    secondQuestion.setText(text2)
    secondQuestionResponse = event.BuilderKeyResponse()
    image.setImage(imageFile)
    # keep track of which components have finished
    TrialComponents = [Trial_Text, Trial_Response, secondQuestion, secondQuestionResponse, image]
    for thisComponent in TrialComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "Trial"-------
    while continueRoutine:
        # get current time
        t = TrialClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Trial_Text* updates
        if t >= 0.0 and Trial_Text.status == NOT_STARTED:
            # keep track of start time/frame for later
            Trial_Text.tStart = t
            Trial_Text.frameNStart = frameN  # exact frame index
            Trial_Text.setAutoDraw(True)
        frameRemains = 0.0 + Text_duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if Trial_Text.status == STARTED and t >= frameRemains:
            Trial_Text.setAutoDraw(False)
        
        # *Trial_Response* updates
        if t >= 0.0 and Trial_Response.status == NOT_STARTED:
            # keep track of start time/frame for later
            Trial_Response.tStart = t
            Trial_Response.frameNStart = frameN  # exact frame index
            Trial_Response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(Trial_Response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = 0.0 + Text_duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if Trial_Response.status == STARTED and t >= frameRemains:
            Trial_Response.status = STOPPED
        if Trial_Response.status == STARTED:
            theseKeys = event.getKeys(keyList=['1', '2', '3', '4', '5', '6', 'space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                Trial_Response.keys = theseKeys[-1]  # just the last key pressed
                Trial_Response.rt = Trial_Response.clock.getTime()
                # was this 'correct'?
                if (Trial_Response.keys == str(corrAns)) or (Trial_Response.keys == corrAns):
                    Trial_Response.corr = 1
                else:
                    Trial_Response.corr = 0
        
        # *secondQuestion* updates
        if t >= text2start and secondQuestion.status == NOT_STARTED:
            # keep track of start time/frame for later
            secondQuestion.tStart = t
            secondQuestion.frameNStart = frameN  # exact frame index
            secondQuestion.setAutoDraw(True)
        frameRemains = text2start + text2duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if secondQuestion.status == STARTED and t >= frameRemains:
            secondQuestion.setAutoDraw(False)
        
        # *secondQuestionResponse* updates
        if t >= text2start and secondQuestionResponse.status == NOT_STARTED:
            # keep track of start time/frame for later
            secondQuestionResponse.tStart = t
            secondQuestionResponse.frameNStart = frameN  # exact frame index
            secondQuestionResponse.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(secondQuestionResponse.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = text2start + text2duration- win.monitorFramePeriod * 0.75  # most of one frame period left
        if secondQuestionResponse.status == STARTED and t >= frameRemains:
            secondQuestionResponse.status = STOPPED
        if secondQuestionResponse.status == STARTED:
            theseKeys = event.getKeys(keyList=['1', '2', '3', '4', '5', '6', 'space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                secondQuestionResponse.keys = theseKeys[-1]  # just the last key pressed
                secondQuestionResponse.rt = secondQuestionResponse.clock.getTime()
                # was this 'correct'?
                if (secondQuestionResponse.keys == str(corrAns)) or (secondQuestionResponse.keys == corrAns):
                    secondQuestionResponse.corr = 1
                else:
                    secondQuestionResponse.corr = 0
        
        # *image* updates
        if t >= 0.0 and image.status == NOT_STARTED:
            # keep track of start time/frame for later
            image.tStart = t
            image.frameNStart = frameN  # exact frame index
            image.setAutoDraw(True)
        frameRemains = 0.0 + imageDur- win.monitorFramePeriod * 0.75  # most of one frame period left
        if image.status == STARTED and t >= frameRemains:
            image.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in TrialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Trial"-------
    for thisComponent in TrialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if Trial_Response.keys in ['', [], None]:  # No response was made
        Trial_Response.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           Trial_Response.corr = 1;  # correct non-response
        else:
           Trial_Response.corr = 0;  # failed to respond (incorrectly)
    # store data for Block2 (TrialHandler)
    Block2.addData('Trial_Response.keys',Trial_Response.keys)
    Block2.addData('Trial_Response.corr', Trial_Response.corr)
    if Trial_Response.keys != None:  # we had a response
        Block2.addData('Trial_Response.rt', Trial_Response.rt)
    # check responses
    if secondQuestionResponse.keys in ['', [], None]:  # No response was made
        secondQuestionResponse.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           secondQuestionResponse.corr = 1;  # correct non-response
        else:
           secondQuestionResponse.corr = 0;  # failed to respond (incorrectly)
    # store data for Block2 (TrialHandler)
    Block2.addData('secondQuestionResponse.keys',secondQuestionResponse.keys)
    Block2.addData('secondQuestionResponse.corr', secondQuestionResponse.corr)
    if secondQuestionResponse.keys != None:  # we had a response
        Block2.addData('secondQuestionResponse.rt', secondQuestionResponse.rt)
    # the Routine "Trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ISI"-------
    t = 0
    ISIClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(0.900000)
    # update component parameters for each repeat
    ISI_Response = event.BuilderKeyResponse()
    # keep track of which components have finished
    ISIComponents = [ISI_Text, ISI_Response]
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "ISI"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = ISIClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ISI_Text* updates
        if t >= 0.0 and ISI_Text.status == NOT_STARTED:
            # keep track of start time/frame for later
            ISI_Text.tStart = t
            ISI_Text.frameNStart = frameN  # exact frame index
            ISI_Text.setAutoDraw(True)
        frameRemains = 0.0 + .9- win.monitorFramePeriod * 0.75  # most of one frame period left
        if ISI_Text.status == STARTED and t >= frameRemains:
            ISI_Text.setAutoDraw(False)
        
        # *ISI_Response* updates
        if t >= 0.0 and ISI_Response.status == NOT_STARTED:
            # keep track of start time/frame for later
            ISI_Response.tStart = t
            ISI_Response.frameNStart = frameN  # exact frame index
            ISI_Response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(ISI_Response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = 0.0 + 0.9- win.monitorFramePeriod * 0.75  # most of one frame period left
        if ISI_Response.status == STARTED and t >= frameRemains:
            ISI_Response.status = STOPPED
        if ISI_Response.status == STARTED:
            theseKeys = event.getKeys(keyList=['1', '2', '3', '4', '5', '6', 'space', 'none'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                ISI_Response.keys = theseKeys[-1]  # just the last key pressed
                ISI_Response.rt = ISI_Response.clock.getTime()
                # was this 'correct'?
                if (ISI_Response.keys == str(corrAns)) or (ISI_Response.keys == corrAns):
                    ISI_Response.corr = 1
                else:
                    ISI_Response.corr = 0
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ISIComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ISI"-------
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if ISI_Response.keys in ['', [], None]:  # No response was made
        ISI_Response.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           ISI_Response.corr = 1;  # correct non-response
        else:
           ISI_Response.corr = 0;  # failed to respond (incorrectly)
    # store data for Block2 (TrialHandler)
    Block2.addData('ISI_Response.keys',ISI_Response.keys)
    Block2.addData('ISI_Response.corr', ISI_Response.corr)
    if ISI_Response.keys != None:  # we had a response
        Block2.addData('ISI_Response.rt', ISI_Response.rt)
    thisExp.nextEntry()
    
# completed 1 repeats of 'Block2'


# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
